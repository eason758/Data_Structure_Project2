#include <iostream>
#include <string>
#include <fstream>
#include "class.h"
#include "floor.h"
#include "func.h"
#include <time.h>


using namespace std;

ifstream f;
ofstream o("final.path", ios::out);

void init(Floor& floor);
void run(Floor& floor);
void output(Floor& floor);

int main(int argc, char *argv[]) {

	double START = clock();
	f.open(argv[1]);
	Floor floor;

	set<coor> s;



	init(floor);

	run(floor);

	output(floor);
	double END = clock();
	cout << "total time: " << (END - START) / CLOCKS_PER_SEC << endl;
	return 0;
}


void init(Floor& floor) {

	floor.unclean_size = 0;
	int r, c, b;
	f >> r >> c >> b;

	floor.map = new cell**[r];
	for (int i = 0; i < r; i++) floor.map[i] = new cell*[c];

	char block;
	for (int i = 0; i < r; i++) {
		for (int j = 0; j < c; j++) {
			f >> block;
			if (block == '1') floor.map[i][j] = new cell(coor(i, j), WALL, -1);
			else if (block == '0')
			{
				floor.map[i][j] = new cell(coor(i, j), ROAD, 0);
				floor.unclean_size++;
			}
			else floor.home = floor.map[i][j] = new cell(coor(i, j), HOME, 0);
		}
	}

	floor.init(r, c, b);

}

void run(Floor& floor) {

	floor.clear();
}

void output(Floor& floor) {

	o << floor.path.size() - 1 << endl;

	int pre_x = floor.path[0].x + 1;
	int pre_y = floor.path[0].y ;

	for (unsigned int i = 0; i < floor.path.size(); i++) {
		if (abs(floor.path[i].x - pre_x) > 1) {
			cout << "wrong!" << endl;
			unsigned int i = 0;
			exit(1);
		}
		if (abs(floor.path[i].y - pre_y) > 1) {
			cout << "wrong!" << endl;
			unsigned int i = 0;
		}
		if (abs(floor.path[i].x - pre_x) + abs(floor.path[i].y - pre_y) > 1) {
			cout << "wrong! > 1" << endl;
			o << "here!" << endl;
			unsigned int i = 0;
		}
		if (abs(floor.path[i].x - pre_x) + abs(floor.path[i].y - pre_y) == 0) {
			cout << "wrong! same step!" << endl;
			unsigned int i = 0;
		}
		if (floor.map[floor.path[i].y][floor.path[i].x]->attr == WALL) {
			cout << "wrong! WALL!" << endl;
			unsigned int i = 0;
		}

		pre_x = floor.path[i].x;
		pre_y = floor.path[i].y;
		
		o << floor.path[i].y << " " << floor.path[i].x << endl;
	}
}
